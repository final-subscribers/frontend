import { atom } from 'recoil';

export const customerState = atom({
  key: 'customerState',
  default: [],
});
