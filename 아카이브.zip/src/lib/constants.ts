export const BASE_URL = 'https://entj.site';
