#!/bin/sh
cd ../
mkdir output
cp -R ./frontend/* ./output
cp -R ./output ./frontend/